"""
程式碼分析模組
使用 Lizard 分析專案程式碼的行數、檔案數量、複雜度等指標
"""
import os
import lizard
from typing import Dict, List, Any
from pathlib import Path


class CodeAnalyzer:
    """程式碼分析器"""

    # 預設排除的資料夾
    DEFAULT_EXCLUDE_FOLDERS = [
        "node_modules", "venv", ".git", "dist", "build",
        "__pycache__", ".venv", "env", ".idea", ".vscode"
    ]

    def __init__(self, project_path: str, exclude_folders: List[str] = None):
        """
        初始化程式碼分析器

        Args:
            project_path: 專案資料夾路徑
            exclude_folders: 自訂排除的資料夾列表，如果為 None 則使用預設值
        """
        self.project_path = Path(project_path)
        if not self.project_path.exists():
            raise ValueError(f"專案路徑不存在: {project_path}")

        # 合併預設和自訂排除資料夾
        if exclude_folders is None:
            self.exclude_folders = self.DEFAULT_EXCLUDE_FOLDERS.copy()
        else:
            self.exclude_folders = self.DEFAULT_EXCLUDE_FOLDERS.copy()
            self.exclude_folders.extend(exclude_folders)

    def analyze(self) -> Dict[str, Any]:
        """
        分析專案程式碼

        Returns:
            包含分析結果的字典
        """
        # 使用 Lizard 分析專案
        # 改進：使用絕對路徑並遞迴分析所有子目錄
        # 將排除資料夾轉換為 regex 格式
        exclude_pattern = self._build_exclude_pattern()

        analysis = lizard.analyze(
            paths=[str(self.project_path.absolute())],
            exclude_pattern=exclude_pattern,
            exts=lizard.get_extensions([])  # 支援所有語言
        )

        # 統計資訊
        total_lines = 0
        total_nloc = 0  # 非空白行數
        total_files = 0
        total_functions = 0
        complexity_sum = 0
        max_complexity = 0
        max_complexity_function = None

        file_details = []

        for file_info in analysis:
            total_files += 1
            total_lines += file_info.nloc
            total_nloc += file_info.nloc

            file_complexity = 0
            file_functions = len(file_info.function_list)
            total_functions += file_functions

            for func in file_info.function_list:
                complexity_sum += func.cyclomatic_complexity
                file_complexity += func.cyclomatic_complexity

                if func.cyclomatic_complexity > max_complexity:
                    max_complexity = func.cyclomatic_complexity
                    max_complexity_function = {
                        'name': func.name,
                        'file': file_info.filename,
                        'complexity': func.cyclomatic_complexity,
                        'line': func.start_line
                    }

            # 檔案詳細資訊
            file_details.append({
                'filename': os.path.relpath(file_info.filename, self.project_path),
                'nloc': file_info.nloc,
                'functions': file_functions,
                'complexity': file_complexity,
                'avg_complexity': round(file_complexity / file_functions, 2) if file_functions > 0 else 0
            })

        # 計算平均複雜度
        avg_complexity = round(complexity_sum / total_functions, 2) if total_functions > 0 else 0

        # 依複雜度排序檔案
        file_details_sorted = sorted(file_details, key=lambda x: x['complexity'], reverse=True)

        return {
            'summary': {
                'total_files': total_files,
                'total_lines': total_lines,
                'total_nloc': total_nloc,
                'total_functions': total_functions,
                'avg_complexity': avg_complexity,
                'max_complexity': max_complexity,
                'max_complexity_function': max_complexity_function
            },
            'files': file_details_sorted[:50],  # 只返回前50個最複雜的檔案
            'complexity_distribution': self._get_complexity_distribution(file_details)
        }

    def _build_exclude_pattern(self) -> str:
        """
        將排除資料夾列表轉換為 Lizard 可接受的 regex 格式

        Returns:
            正規表達式字串
        """
        # 對特殊字元進行跳脫
        escaped_folders = [folder.replace('.', r'\.') for folder in self.exclude_folders]
        # 組合成 regex 格式：(folder1|folder2|folder3|...)
        pattern = r"(" + "|".join(escaped_folders) + r")"
        return pattern

    def _get_complexity_distribution(self, file_details: List[Dict]) -> Dict[str, int]:
        """
        計算複雜度分佈

        Args:
            file_details: 檔案詳細資訊列表

        Returns:
            複雜度分佈統計
        """
        distribution = {
            'low': 0,       # 複雜度 1-5
            'medium': 0,    # 複雜度 6-10
            'high': 0,      # 複雜度 11-20
            'very_high': 0  # 複雜度 > 20
        }

        for file_info in file_details:
            complexity = file_info['avg_complexity']
            if complexity <= 5:
                distribution['low'] += 1
            elif complexity <= 10:
                distribution['medium'] += 1
            elif complexity <= 20:
                distribution['high'] += 1
            else:
                distribution['very_high'] += 1

        return distribution
